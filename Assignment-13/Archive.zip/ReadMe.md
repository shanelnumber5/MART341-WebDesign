# Assignment 13 ReadMe Questions and Answers

## 1. Who was your imaginary client? How did they describe their site needs?

I wanted to choose a type of client I might be somewhat familiar with so I could think about "their" needs more clearly.  Since I used to make re-enlistment  and ceremony cakes in the Navy and then worked at a high-end bakeshop in San Diego right after I ended my time in the service, I decided to go with a wedding cake business. Anyone who works in this business can tell you cupcakes and party cakes can make some money, but where much of your business revenue comes from is from the wedding cakes themselves.  I looked at other examples online of wedding cake businesses and I modeled my design off what others were doing in this type of business now, without stealing their design.  I found that many bakeries that specialize in wedding cakes showcase much of their previous work in a somewhat busy fashion on the website itself.

## 2. Why is it important to consider a mobile-first design?

Your design should look good on every sized screen.  Since a phone has one of the smallest screens and accounts for more than half of the internet traffic.  It is a smart to give your website the ability to be able to sized to any size screen to accommodate this wide variety of traffic.

## 3. Free Response: Please discuss your challenges and how you overcame them.

Designing a logo for my business in Illustrator and coming up with a name took a large amount of time.  I really need to become more proficient in Illustrator, it is so different from Photoshop.  After I designed my logo for this fictious business, I honestly struggled with formatting  issues and getting the items to fit properly in any format.  I just get so particular on what I want my site to look like, it is hard for me to just throw in the towel sometimes, but I do persevere and am proud of my results.
